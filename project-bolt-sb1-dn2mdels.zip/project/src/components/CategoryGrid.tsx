import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import CategoryCard from './CategoryCard';
import { Category } from '../types';

interface CategoryGridProps {
  categories: Category[];
  title: string;
  subtitle?: string;
  viewAllLink?: string;
}

const CategoryGrid: React.FC<CategoryGridProps> = ({
  categories,
  title,
  subtitle,
  viewAllLink = '/categories',
}) => {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">{title}</h2>
            {subtitle && <p className="mt-2 text-gray-600">{subtitle}</p>}
          </div>
          
          <Link
            to={viewAllLink}
            className="text-indigo-600 hover:text-indigo-800 flex items-center text-sm font-medium"
          >
            View All
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;