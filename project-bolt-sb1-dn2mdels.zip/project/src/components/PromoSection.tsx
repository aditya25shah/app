import React from 'react';
import { Link } from 'react-router-dom';
import { Truck, ShieldCheck, RotateCcw, Clock } from 'lucide-react';

const PromoSection: React.FC = () => {
  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-y-8 sm:grid-cols-2 sm:gap-x-6 lg:grid-cols-4">
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100">
              <Truck className="h-6 w-6 text-indigo-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">Free Shipping</h3>
            <p className="mt-2 text-sm text-gray-500">
              Free shipping on all orders over $50
            </p>
          </div>

          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100">
              <ShieldCheck className="h-6 w-6 text-indigo-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">Secure Payments</h3>
            <p className="mt-2 text-sm text-gray-500">
              100% secure payment processing
            </p>
          </div>

          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100">
              <RotateCcw className="h-6 w-6 text-indigo-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">Easy Returns</h3>
            <p className="mt-2 text-sm text-gray-500">
              30-day money-back guarantee
            </p>
          </div>

          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100">
              <Clock className="h-6 w-6 text-indigo-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">24/7 Support</h3>
            <p className="mt-2 text-sm text-gray-500">
              Customer support available 24/7
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PromoSection;