import React from 'react';
import { Link } from 'react-router-dom';
import { Category } from '../types';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link to={`/category/${category.id}`} className="block group">
      <div className="relative rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
        <div className="aspect-w-16 aspect-h-9">
          <img
            src={category.imageUrl}
            alt={category.name}
            className="w-full h-48 object-cover object-center group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
          <div className="p-4 w-full">
            <h3 className="text-xl font-bold text-white">{category.name}</h3>
            {category.subcategories && (
              <p className="text-sm text-gray-200 mt-1">
                {category.subcategories.length} subcategories
              </p>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default CategoryCard;