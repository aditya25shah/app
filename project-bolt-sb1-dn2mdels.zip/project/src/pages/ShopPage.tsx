import React, { useState, useEffect } from 'react';
import { Filter, SlidersHorizontal, ChevronDown, X } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';
import { categories } from '../data/categories';
import { Product } from '../types';

const ShopPage: React.FC = () => {
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2000]);
  const [sortBy, setSortBy] = useState<string>('featured');
  const [filtersOpen, setFiltersOpen] = useState(false);

  // Apply filters
  useEffect(() => {
    let result = [...products];
    
    // Search filter
    if (searchQuery) {
      result = result.filter(product => 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    // Category filter
    if (selectedCategory) {
      result = result.filter(product => product.category === selectedCategory);
      
      // Subcategory filter (only if category is selected)
      if (selectedSubcategory) {
        result = result.filter(product => product.subcategory === selectedSubcategory);
      }
    }
    
    // Price range filter
    result = result.filter(product => {
      const price = product.discountedPrice || product.price;
      return price >= priceRange[0] && price <= priceRange[1];
    });
    
    // Sorting
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => {
          const priceA = a.discountedPrice || a.price;
          const priceB = b.discountedPrice || b.price;
          return priceA - priceB;
        });
        break;
      case 'price-high':
        result.sort((a, b) => {
          const priceA = a.discountedPrice || a.price;
          const priceB = b.discountedPrice || b.price;
          return priceB - priceA;
        });
        break;
      case 'newest':
        result.sort((a, b) => (a.new === b.new ? 0 : a.new ? -1 : 1));
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      default: // featured
        result.sort((a, b) => (a.featured === b.featured ? 0 : a.featured ? -1 : 1));
    }
    
    setFilteredProducts(result);
  }, [searchQuery, selectedCategory, selectedSubcategory, priceRange, sortBy]);

  // Get subcategories for selected category
  const subcategories = selectedCategory
    ? categories.find(cat => cat.name === selectedCategory)?.subcategories || []
    : [];

  // Reset filters
  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory(null);
    setSelectedSubcategory(null);
    setPriceRange([0, 2000]);
    setSortBy('featured');
  };

  // Toggle mobile filters
  const toggleFilters = () => {
    setFiltersOpen(!filtersOpen);
  };

  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Shop All Products</h1>
            <p className="mt-1 text-sm text-gray-500">
              {filteredProducts.length} {filteredProducts.length === 1 ? 'product' : 'products'} available
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center">
            <button
              onClick={toggleFilters}
              className="md:hidden flex items-center text-gray-700 mr-4"
            >
              <Filter className="h-5 w-5 mr-1" />
              Filters
            </button>
            
            <div className="flex items-center">
              <label htmlFor="sort" className="text-sm font-medium text-gray-700 mr-2">
                Sort by:
              </label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="rounded-md border-gray-300 py-2 pl-3 pr-10 text-sm focus:border-indigo-500 focus:outline-none focus:ring-indigo-500"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="newest">Newest</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="hidden md:block w-64 flex-shrink-0">
            <div className="sticky top-20">
              <div className="pb-6 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-900 flex items-center justify-between">
                  Filters
                  <button
                    onClick={resetFilters}
                    className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
                  >
                    Reset
                  </button>
                </h2>
                
                <div className="mt-4">
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>
              </div>
              
              <div className="py-6 border-b border-gray-200">
                <h3 className="text-sm font-medium text-gray-900 mb-4">Categories</h3>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <div key={category.id} className="flex items-center">
                      <input
                        id={`category-${category.id}`}
                        name="category"
                        type="radio"
                        checked={selectedCategory === category.name}
                        onChange={() => {
                          setSelectedCategory(category.name);
                          setSelectedSubcategory(null);
                        }}
                        className="h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <label
                        htmlFor={`category-${category.id}`}
                        className="ml-3 text-sm text-gray-600"
                      >
                        {category.name}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              {selectedCategory && subcategories.length > 0 && (
                <div className="py-6 border-b border-gray-200">
                  <h3 className="text-sm font-medium text-gray-900 mb-4">Subcategories</h3>
                  <div className="space-y-2">
                    {subcategories.map((subcategory) => (
                      <div key={subcategory.id} className="flex items-center">
                        <input
                          id={`subcategory-${subcategory.id}`}
                          name="subcategory"
                          type="radio"
                          checked={selectedSubcategory === subcategory.name}
                          onChange={() => setSelectedSubcategory(subcategory.name)}
                          className="h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <label
                          htmlFor={`subcategory-${subcategory.id}`}
                          className="ml-3 text-sm text-gray-600"
                        >
                          {subcategory.name}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="py-6 border-b border-gray-200">
                <h3 className="text-sm font-medium text-gray-900 mb-4">Price Range</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">${priceRange[0]}</span>
                    <span className="text-sm text-gray-600">${priceRange[1]}</span>
                  </div>
                  <div className="flex space-x-4">
                    <input
                      type="range"
                      min="0"
                      max="2000"
                      step="10"
                      value={priceRange[0]}
                      onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                      className="w-full"
                    />
                    <input
                      type="range"
                      min="0"
                      max="2000"
                      step="10"
                      value={priceRange[1]}
                      onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                      className="w-full"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Filters - Mobile */}
          {filtersOpen && (
            <div className="fixed inset-0 z-40 flex md:hidden">
              <div className="fixed inset-0 bg-black bg-opacity-25" onClick={toggleFilters}></div>
              <div className="relative max-w-xs w-full h-full bg-white shadow-xl flex flex-col overflow-y-auto">
                <div className="px-4 py-5 flex items-center justify-between">
                  <h2 className="text-lg font-medium text-gray-900">Filters</h2>
                  <button
                    type="button"
                    className="-mr-2 w-10 h-10 flex items-center justify-center text-gray-400 hover:text-gray-500"
                    onClick={toggleFilters}
                  >
                    <X className="h-6 w-6" />
                  </button>
                </div>
                
                <div className="px-4 py-4 border-t border-gray-200">
                  <h3 className="text-sm font-medium text-gray-900 mb-4">Search</h3>
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>
                
                <div className="px-4 py-4 border-t border-gray-200">
                  <h3 className="text-sm font-medium text-gray-900 mb-4">Categories</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <div key={category.id} className="flex items-center">
                        <input
                          id={`mobile-category-${category.id}`}
                          name="mobile-category"
                          type="radio"
                          checked={selectedCategory === category.name}
                          onChange={() => {
                            setSelectedCategory(category.name);
                            setSelectedSubcategory(null);
                          }}
                          className="h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <label
                          htmlFor={`mobile-category-${category.id}`}
                          className="ml-3 text-sm text-gray-600"
                        >
                          {category.name}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                {selectedCategory && subcategories.length > 0 && (
                  <div className="px-4 py-4 border-t border-gray-200">
                    <h3 className="text-sm font-medium text-gray-900 mb-4">Subcategories</h3>
                    <div className="space-y-2">
                      {subcategories.map((subcategory) => (
                        <div key={subcategory.id} className="flex items-center">
                          <input
                            id={`mobile-subcategory-${subcategory.id}`}
                            name="mobile-subcategory"
                            type="radio"
                            checked={selectedSubcategory === subcategory.name}
                            onChange={() => setSelectedSubcategory(subcategory.name)}
                            className="h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-500"
                          />
                          <label
                            htmlFor={`mobile-subcategory-${subcategory.id}`}
                            className="ml-3 text-sm text-gray-600"
                          >
                            {subcategory.name}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="px-4 py-4 border-t border-gray-200">
                  <h3 className="text-sm font-medium text-gray-900 mb-4">Price Range</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">${priceRange[0]}</span>
                      <span className="text-sm text-gray-600">${priceRange[1]}</span>
                    </div>
                    <div className="flex space-x-4">
                      <input
                        type="range"
                        min="0"
                        max="2000"
                        step="10"
                        value={priceRange[0]}
                        onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                        className="w-full"
                      />
                      <input
                        type="range"
                        min="0"
                        max="2000"
                        step="10"
                        value={priceRange[1]}
                        onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="px-4 py-4 border-t border-gray-200">
                  <button
                    onClick={() => {
                      resetFilters();
                      toggleFilters();
                    }}
                    className="w-full bg-indigo-600 border border-transparent rounded-md py-2 px-4 flex items-center justify-center text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Reset Filters
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Product grid */}
          <div className="flex-1">
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
                <p className="text-gray-500">Try adjusting your filters or search query.</p>
                <button
                  onClick={resetFilters}
                  className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShopPage;