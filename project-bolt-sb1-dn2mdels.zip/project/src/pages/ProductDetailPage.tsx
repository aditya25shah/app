import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Truck, ShieldCheck, ArrowLeft, Heart, Share2, Minus, Plus } from 'lucide-react';
import { products } from '../data/products';
import { useCart } from '../context/CartContext';
import ProductCard from '../components/ProductCard';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  
  const product = products.find(p => p.id === id);
  
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState(product?.colors?.[0] || '');
  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0] || '');
  const [activeTab, setActiveTab] = useState('description');
  
  // Find related products (same category)
  const relatedProducts = products
    .filter(p => p.category === product?.category && p.id !== product?.id)
    .slice(0, 4);
  
  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h1>
        <p className="text-gray-600 mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Link
          to="/shop"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Shop
        </Link>
      </div>
    );
  }
  
  const handleAddToCart = () => {
    addToCart(product, quantity, selectedColor, selectedSize);
  };
  
  const incrementQuantity = () => {
    setQuantity(prev => prev + 1);
  };
  
  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };
  
  const discountPercentage = product.discountedPrice 
    ? Math.round(((product.price - product.discountedPrice) / product.price) * 100) 
    : 0;

  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <nav className="flex mb-8" aria-label="Breadcrumb">
          <ol className="flex items-center space-x-2">
            <li>
              <Link to="/" className="text-gray-500 hover:text-gray-700">Home</Link>
            </li>
            <li className="flex items-center">
              <span className="mx-2 text-gray-400">/</span>
              <Link to="/shop" className="text-gray-500 hover:text-gray-700">Shop</Link>
            </li>
            <li className="flex items-center">
              <span className="mx-2 text-gray-400">/</span>
              <Link to={`/category/${product.category}`} className="text-gray-500 hover:text-gray-700">
                {product.category}
              </Link>
            </li>
            <li className="flex items-center">
              <span className="mx-2 text-gray-400">/</span>
              <span className="text-gray-900 font-medium">{product.name}</span>
            </li>
          </ol>
        </nav>
        
        <div className="lg:grid lg:grid-cols-2 lg:gap-x-8">
          {/* Product image */}
          <div className="lg:max-w-lg lg:self-end">
            <div className="aspect-w-1 aspect-h-1 rounded-lg overflow-hidden">
              <img
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-full object-center object-cover"
              />
            </div>
          </div>
          
          {/* Product details */}
          <div className="mt-10 lg:mt-0 lg:max-w-lg lg:self-start">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-extrabold tracking-tight text-gray-900">{product.name}</h1>
                <p className="mt-1 text-sm text-gray-500">{product.category} {product.subcategory && `/ ${product.subcategory}`}</p>
              </div>
              <div className="flex space-x-2">
                <button className="p-2 rounded-full text-gray-400 hover:text-red-500 hover:bg-gray-100">
                  <Heart size={20} />
                </button>
                <button className="p-2 rounded-full text-gray-400 hover:text-indigo-500 hover:bg-gray-100">
                  <Share2 size={20} />
                </button>
              </div>
            </div>
            
            <div className="mt-3 flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={20}
                  className={`${
                    i < Math.floor(product.rating) 
                      ? 'text-yellow-400' 
                      : 'text-gray-300'
                  }`}
                  fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'}
                />
              ))}
              <span className="ml-2 text-sm text-gray-500">({product.reviewCount} reviews)</span>
            </div>
            
            <div className="mt-4">
              <div className="flex items-center">
                {product.discountedPrice ? (
                  <>
                    <p className="text-3xl font-bold text-gray-900">${product.discountedPrice.toFixed(2)}</p>
                    <p className="ml-3 text-lg text-gray-500 line-through">${product.price.toFixed(2)}</p>
                    <span className="ml-3 px-2 py-1 text-xs font-semibold text-white bg-red-500 rounded">
                      {discountPercentage}% OFF
                    </span>
                  </>
                ) : (
                  <p className="text-3xl font-bold text-gray-900">${product.price.toFixed(2)}</p>
                )}
              </div>
              
              <p className="mt-1 text-sm text-gray-500">
                {product.inStock ? (
                  <span className="text-green-600">In Stock</span>
                ) : (
                  <span className="text-red-600">Out of Stock</span>
                )}
                {product.stockCount && product.stockCount < 10 && (
                  <span className="ml-2 text-orange-500">Only {product.stockCount} left!</span>
                )}
              </p>
            </div>
            
            <div className="mt-6">
              {product.colors && product.colors.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-900">Color</h3>
                  <div className="mt-2 flex space-x-2">
                    {product.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`
                          px-3 py-1 rounded-md text-sm
                          ${selectedColor === color 
                            ? 'bg-indigo-600 text-white' 
                            : 'bg-gray-200 text-gray-800 hover:bg-gray-300'}
                        `}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {product.sizes && product.sizes.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-900">Size</h3>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`
                          px-3 py-1 rounded-md text-sm
                          ${selectedSize === size 
                            ? 'bg-indigo-600 text-white' 
                            : 'bg-gray-200 text-gray-800 hover:bg-gray-300'}
                        `}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900">Quantity</h3>
                <div className="mt-2 flex items-center">
                  <button
                    onClick={decrementQuantity}
                    className="p-2 rounded-l-md border border-gray-300 bg-gray-50 text-gray-600 hover:bg-gray-100"
                  >
                    <Minus size={16} />
                  </button>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                    className="p-2 w-16 text-center border-t border-b border-gray-300"
                  />
                  <button
                    onClick={incrementQuantity}
                    className="p-2 rounded-r-md border border-gray-300 bg-gray-50 text-gray-600 hover:bg-gray-100"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <button
                  onClick={handleAddToCart}
                  disabled={!product.inStock}
                  className={`
                    flex-1 px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white 
                    ${product.inStock 
                      ? 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500' 
                      : 'bg-gray-400 cursor-not-allowed'}
                  `}
                >
                  Add to Cart
                </button>
                <button
                  className="px-6 py-3 border border-gray-300 rounded-md shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Buy Now
                </button>
              </div>
            </div>
            
            <div className="mt-8 border-t border-gray-200 pt-6">
              <div className="flex space-x-6">
                <div className="flex items-center">
                  <Truck className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm text-gray-600">Free shipping over $50</span>
                </div>
                <div className="flex items-center">
                  <ShieldCheck className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm text-gray-600">30-day returns</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Product tabs */}
        <div className="mt-16">
          <div className="border-b border-gray-200">
            <div className="flex space-x-8">
              <button
                onClick={() => setActiveTab('description')}
                className={`
                  py-4 text-sm font-medium border-b-2 
                  ${activeTab === 'description' 
                    ? 'border-indigo-600 text-indigo-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                `}
              >
                Description
              </button>
              <button
                onClick={() => setActiveTab('specifications')}
                className={`
                  py-4 text-sm font-medium border-b-2 
                  ${activeTab === 'specifications' 
                    ? 'border-indigo-600 text-indigo-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                `}
              >
                Specifications
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`
                  py-4 text-sm font-medium border-b-2 
                  ${activeTab === 'reviews' 
                    ? 'border-indigo-600 text-indigo-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                `}
              >
                Reviews ({product.reviewCount})
              </button>
            </div>
          </div>
          
          <div className="py-6">
            {activeTab === 'description' && (
              <div className="prose prose-indigo max-w-none">
                <p className="text-gray-700">{product.description}</p>
                <p className="mt-4 text-gray-700">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                </p>
                <ul className="mt-4 list-disc pl-5 text-gray-700">
                  <li>Premium quality materials</li>
                  <li>Designed for durability and performance</li>
                  <li>Ergonomic design for maximum comfort</li>
                  <li>Compatible with all standard accessories</li>
                </ul>
              </div>
            )}
            
            {activeTab === 'specifications' && (
              <div className="border-t border-gray-200">
                <dl>
                  <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Brand</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">ShopHub</dd>
                  </div>
                  <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Model</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">SH-{product.id}</dd>
                  </div>
                  <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Dimensions</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">10 x 5 x 3 inches</dd>
                  </div>
                  <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Weight</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">1.5 lbs</dd>
                  </div>
                  <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Material</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">Premium quality</dd>
                  </div>
                  <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Warranty</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">1 year limited warranty</dd>
                  </div>
                </dl>
              </div>
            )}
            
            {activeTab === 'reviews' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-medium text-gray-900">Customer Reviews</h3>
                  <button className="px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                    Write a Review
                  </button>
                </div>
                
                <div className="space-y-8">
                  {/* Sample reviews */}
                  <div className="border-b border-gray-200 pb-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <img
                          className="h-10 w-10 rounded-full"
                          src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                          alt="Reviewer"
                        />
                      </div>
                      <div className="ml-4">
                        <h4 className="text-sm font-bold text-gray-900">John Doe</h4>
                        <div className="mt-1 flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              size={16}
                              className={i < 5 ? 'text-yellow-400' : 'text-gray-300'}
                              fill={i < 5 ? 'currentColor' : 'none'}
                            />
                          ))}
                          <span className="ml-2 text-sm text-gray-500">2 months ago</span>
                        </div>
                        <p className="mt-2 text-sm text-gray-600">
                          Absolutely love this product! The quality is exceptional and it works exactly as described. Would definitely recommend to anyone looking for a reliable solution.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-b border-gray-200 pb-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <img
                          className="h-10 w-10 rounded-full"
                          src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                          alt="Reviewer"
                        />
                      </div>
                      <div className="ml-4">
                        <h4 className="text-sm font-bold text-gray-900">Jane Smith</h4>
                        <div className="mt-1 flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              size={16}
                              className={i < 4 ? 'text-yellow-400' : 'text-gray-300'}
                              fill={i < 4 ? 'currentColor' : 'none'}
                            />
                          ))}
                          <span className="ml-2 text-sm text-gray-500">1 month ago</span>
                        </div>
                        <p className="mt-2 text-sm text-gray-600">
                          Great product overall. Shipping was fast and the item arrived in perfect condition. The only reason I'm giving 4 stars instead of 5 is that the color is slightly different from what's shown in the pictures.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <button className="text-sm font-medium text-indigo-600 hover:text-indigo-500">
                      Load more reviews
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Related products */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">You may also like</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;