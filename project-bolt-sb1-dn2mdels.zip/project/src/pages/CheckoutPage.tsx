import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const CheckoutPage: React.FC = () => {
  const { cart, subtotal, clearCart } = useCart();
  const { user, isAuthenticated } = useAuth();
  
  const [step, setStep] = useState(1);
  const [shippingAddress, setShippingAddress] = useState({
    fullName: user?.name || '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'United States',
    phone: ''
  });
  
  const [billingAddress, setBillingAddress] = useState({
    fullName: user?.name || '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'United States',
    phone: ''
  });
  
  const [sameAsShipping, setSameAsShipping] = useState(true);
  const [paymentMethod, setPaymentMethod] = useState('credit-card');
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    cardName: '',
    expiryDate: '',
    cvv: ''
  });
  
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderId, setOrderId] = useState('');
  
  const shippingCost = subtotal > 50 ? 0 : 5.99;
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + shippingCost + tax;
  
  const handleShippingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setShippingAddress(prev => ({ ...prev, [name]: value }));
    
    if (sameAsShipping) {
      setBillingAddress(prev => ({ ...prev, [name]: value }));
    }
  };
  
  const handleBillingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setBillingAddress(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSameAsShippingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSameAsShipping(e.target.checked);
    if (e.target.checked) {
      setBillingAddress(shippingAddress);
    }
  };
  
  const handleCardDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCardDetails(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step === 1) {
      setStep(2);
    } else if (step === 2) {
      // In a real app, this would send the order to a backend
      // For demo purposes, we'll just simulate a successful order
      setTimeout(() => {
        setOrderId(`ORD-${Math.floor(Math.random() * 1000000)}`);
        setOrderPlaced(true);
        clearCart();
      }, 1500);
    }
  };
  
  if (cart.length === 0 && !orderPlaced) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Your cart is empty</h1>
        <p className="text-gray-600 mb-6">Add some products to your cart before proceeding to checkout.</p>
        <Link
          to="/shop"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
        >
          Continue Shopping
        </Link>
      </div>
    );
  }
  
  if (orderPlaced) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <svg
            className="mx-auto h-12 w-12 text-green-600"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M5 13l4 4L19 7"
            />
          </svg>
          <h2 className="mt-4 text-3xl font-extrabold text-gray-900">Order Placed Successfully!</h2>
          <p className="mt-2 text-lg text-gray-600">
            Thank you for your purchase. Your order has been placed successfully.
          </p>
          <p className="mt-1 text-lg font-medium text-gray-900">
            Order ID: {orderId}
          </p>
          <p className="mt-4 text-sm text-gray-500">
            A confirmation email has been sent to your email address.
          </p>
          <div className="mt-8">
            <Link
              to="/orders"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 mr-4"
            >
              View Order
            </Link>
            <Link
              to="/"
              className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50"
            >
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Checkout</h1>
        
        <div className="lg:grid lg:grid-cols-12 lg:gap-x-12">
          <div className="lg:col-span-7">
            <div className="bg-white shadow-sm rounded-lg mb-6">
              <div className="px-4 py-5 sm:p-6">
                <h2 className="text-lg font-medium text-gray-900 mb-4">
                  {step === 1 ? 'Shipping Information' : 'Payment Information'}
                </h2>
                
                <form onSubmit={handleSubmit}>
                  {step === 1 ? (
                    <>
                      <div className="grid grid-cols-6 gap-6">
                        <div className="col-span-6">
                          <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">
                            Full name
                          </label>
                          <input
                            type="text"
                            name="fullName"
                            id="fullName"
                            value={shippingAddress.fullName}
                            onChange={handleShippingChange}
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          />
                        </div>
                        
                        <div className="col-span-6">
                          <label htmlFor="addressLine1" className="block text-sm font-medium text-gray-700">
                            Street address
                          </label>
                          <input
                            type="text"
                            name="addressLine1"
                            id="addressLine1"
                            value={shippingAddress.addressLine1}
                            onChange={handleShippingChange}
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          />
                        </div>
                        
                        <div className="col-span-6">
                          <label htmlFor="addressLine2" className="block text-sm font-medium text-gray-700">
                            Apartment, suite, etc. (optional)
                          </label>
                          <input
                            type="text"
                            name="addressLine2"
                            id="addressLine2"
                            value={shippingAddress.addressLine2}
                            onChange={handleShippingChange}
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          />
                        </div>
                        
                        <div className="col-span-6 sm:col-span-3">
                          <label htmlFor="city" className="block text-sm font-medium text-gray-700">
                            City
                          </label>
                          <input
                            type="text"
                            name="city"
                            id="city"
                            value={shippingAddress.city}
                            onChange={handleShippingChange}
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          />
                        </div>
                        
                        <div className="col-span-6 sm:col-span-3">
                          <label htmlFor="state" className="block text-sm font-medium text-gray-700">
                            State / Province
                          </label>
                          <input
                            type="text"
                            name="state"
                            id="state"
                            value={shippingAddress.state}
                            onChange={handleShippingChange}
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          />
                        </div>
                        
                        <div className="col-span-6 sm:col-span-3">
                          <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700">
                            ZIP / Postal code
                          </label>
                          <input
                            type="text"
                            name="postalCode"
                            id="postalCode"
                            value={shippingAddress.postalCode}
                            onChange={handleShippingChange}
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          />
                        </div>
                        
                        <div className="col-span-6 sm:col-span-3">
                          <label htmlFor="country" className="block text-sm font-medium text-gray-700">
                            Country
                          </label>
                          <select
                            id="country"
                            name="country"
                            value={shippingAddress.country}
                            onChange={handleShippingChange}
                            className="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          >
                            <option value="United States">United States</option>
                            <option value="Canada">Canada</option>
                            <option value="Mexico">Mexico</option>
                            <option value="United Kingdom">United Kingdom</option>
                          </select>
                        </div>
                        
                        <div className="col-span-6">
                          <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                            Phone number
                          </label>
                          <input
                            type="tel"
                            name="phone"
                            id="phone"
                            value={shippingAddress.phone}
                            onChange={handleShippingChange}
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          />
                        </div>
                      </div>
                      
                      <div className="mt-6">
                        <div className="flex items-center">
                          <input
                            id="same-as-shipping"
                            name="same-as-shipping"
                            type="checkbox"
                            checked={sameAsShipping}
                            onChange={handleSameAsShippingChange}
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                          />
                          <label htmlFor="same-as-shipping" className="ml-2 block text-sm text-gray-900">
                            Billing address is the same as shipping address
                          </label>
                        </div>
                      </div>
                      
                      {!sameAsShipping && (
                        <div className="mt-6">
                          <h3 className="text-lg font-medium text-gray-900 mb-4">Billing Information</h3>
                          <div className="grid grid-cols-6 gap-6">
                            <div className="col-span-6">
                              <label htmlFor="billing-fullName" className="block text-sm font-medium text-gray-700">
                                Full name
                              </label>
                              <input
                                type="text"
                                name="fullName"
                                id="billing-fullName"
                                value={billingAddress.fullName}
                                onChange={handleBillingChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-6">
                              <label htmlFor="billing-addressLine1" className="block text-sm font-medium text-gray-700">
                                Street address
                              </label>
                              <input
                                type="text"
                                name="addressLine1"
                                id="billing-addressLine1"
                                value={billingAddress.addressLine1}
                                onChange={handleBillingChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-6">
                              <label htmlFor="billing-addressLine2" className="block text-sm font-medium text-gray-700">
                                Apartment, suite, etc. (optional)
                              </label>
                              <input
                                type="text"
                                name="addressLine2"
                                id="billing-addressLine2"
                                value={billingAddress.addressLine2}
                                onChange={handleBillingChange}
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-6 sm:col-span-3">
                              <label htmlFor="billing-city" className="block text-sm font-medium text-gray-700">
                                City
                              </label>
                              <input
                                type="text"
                                name="city"
                                id="billing-city"
                                value={billingAddress.city}
                                onChange={handleBillingChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-6 sm:col-span-3">
                              <label htmlFor="billing-state" className="block text-sm font-medium text-gray-700">
                                State / Province
                              </label>
                              <input
                                type="text"
                                name="state"
                                id="billing-state"
                                value={billingAddress.state}
                                onChange={handleBillingChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-6 sm:col-span-3">
                              <label htmlFor="billing-postalCode" className="block text-sm font-medium text-gray-700">
                                ZIP / Postal code
                              </label>
                              <input
                                type="text"
                                name="postalCode"
                                id="billing-postalCode"
                                value={billingAddress.postalCode}
                                onChange={handleBillingChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-6 sm:col-span-3">
                              <label htmlFor="billing-country" className="block text-sm font-medium text-gray-700">
                                Country
                              </label>
                              <select
                                id="billing-country"
                                name="country"
                                value={billingAddress.country}
                                onChange={handleBillingChange}
                                className="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              >
                                <option value="United States">United States</option>
                                <option value="Canada">Canada</option>
                                <option value="Mexico">Mexico</option>
                                <option value="United Kingdom">United Kingdom</option>
                              </select>
                            </div>
                            
                            <div className="col-span-6">
                              <label htmlFor="billing-phone" className="block text-sm font-medium text-gray-700">
                                Phone number
                              </label>
                              <input
                                type="tel"
                                name="phone"
                                id="billing-phone"
                                value={billingAddress.phone}
                                onChange={handleBillingChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="space-y-6">
                        <div>
                          <label className="text-base font-medium text-gray-900">Payment method</label>
                          <div className="mt-4 space-y-4">
                            <div className="flex items-center">
                              <input
                                id="credit-card"
                                name="payment-method"
                                type="radio"
                                checked={paymentMethod === 'credit-card'}
                                onChange={() => setPaymentMethod('credit-card')}
                                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300"
                              />
                              <label htmlFor="credit-card" className="ml-3 block text-sm font-medium text-gray-700">
                                Credit / Debit Card
                              </label>
                            </div>
                            <div className="flex items-center">
                              <input
                                id="paypal"
                                name="payment-method"
                                type="radio"
                                checked={paymentMethod === 'paypal'}
                                onChange={() => setPaymentMethod('paypal')}
                                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300"
                              />
                              <label htmlFor="paypal" className="ml-3 block text-sm font-medium text-gray-700">
                                PayPal
                              </label>
                            </div>
                          </div>
                        </div>
                        
                        {paymentMethod === 'credit-card' && (
                          <div className="grid grid-cols-6 gap-6">
                            <div className="col-span-6">
                              <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700">
                                Card number
                              </label>
                              <input
                                type="text"
                                name="cardNumber"
                                id="cardNumber"
                                placeholder="1234 5678 9012 3456"
                                value={cardDetails.cardNumber}
                                onChange={handleCardDetailsChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-6">
                              <label htmlFor="cardName" className="block text-sm font-medium text-gray-700">
                                Name on card
                              </label>
                              <input
                                type="text"
                                name="cardName"
                                id="cardName"
                                value={cardDetails.cardName}
                                onChange={handleCardDetailsChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-3">
                              <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700">
                                Expiry date (MM/YY)
                              </label>
                              <input
                                type="text"
                                name="expiryDate"
                                id="expiryDate"
                                placeholder="MM/YY"
                                value={cardDetails.expiryDate}
                                onChange={handleCardDetailsChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                            
                            <div className="col-span-3">
                              <label htmlFor="cvv" className="block text-sm font-medium text-gray-700">
                                CVV
                              </label>
                              <input
                                type="text"
                                name="cvv"
                                id="cvv"
                                placeholder="123"
                                value={cardDetails.cvv}
                                onChange={handleCardDetailsChange}
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              />
                            </div>
                          </div>
                        )}
                        
                        {paymentMethod === 'paypal' && (
                          <div className="bg-gray-50 p-4 rounded-md">
                            <p className="text-sm text-gray-700">
                              You will be redirected to PayPal to complete your payment.
                            </p>
                          </div>
                        )}
                      </div>
                    </>
                  )}
                  
                  <div className="mt-8 flex justify-between">
                    {step === 2 && (
                      <button
                        type="button"
                        onClick={() => setStep(1)}
                        className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                      >
                        Back
                      </button>
                    )}
                    <button
                      type="submit"
                      className={`${
                        step === 1 ? 'ml-auto' : ''
                      } inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
                    >
                      {step === 1 ? 'Continue to Payment' : 'Place Order'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-5">
            <div className="bg-white shadow-sm rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <h2 className="text-lg font-medium text-gray-900 mb-4">Order Summary</h2>
                
                <div className="flow-root">
                  <ul className="-my-4 divide-y divide-gray-200">
                    {cart.map((item) => (
                      <li key={`${item.product.id}-${item.selectedColor}-${item.selectedSize}`} className="py-4 flex">
                        <div className="flex-shrink-0 w-16 h-16 border border-gray-200 rounded-md overflow-hidden">
                          <img
                            src={item.product.imageUrl}
                            alt={item.product.name}
                            className="w-full h-full object-center object-cover"
                          />
                        </div>
                        
                        <div className="ml-4 flex-1 flex flex-col">
                          <div>
                            <div className="flex justify-between text-sm font-medium text-gray-900">
                              <h3>{item.product.name}</h3>
                              <p className="ml-4">
                                ${((item.product.discountedPrice || item.product.price) * item.quantity).toFixed(2)}
                              </p>
                            </div>
                            <p className="mt-1 text-sm text-gray-500">{item.product.category}</p>
                          </div>
                          <div className="flex-1 flex items-end justify-between text-sm">
                            <p className="text-gray-500">Qty {item.quantity}</p>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <dl className="mt-8 space-y-4">
                  <div className="flex items-center justify-between">
                    <dt className="text-sm text-gray-600">Subtotal</dt>
                    <dd className="text-sm font-medium text-gray-900">${subtotal.toFixed(2)}</dd>
                  </div>
                  <div className="flex items-center justify-between">
                    <dt className="text-sm text-gray-600">Shipping</dt>
                    <dd className="text-sm font-medium text-gray-900">
                      {shippingCost === 0 ? (
                        <span className="text-green-600">Free</span>
                      ) : (
                        `$${shippingCost.toFixed(2)}`
                      )}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between">
                    <dt className="text-sm text-gray-600">Tax</dt>
                    <dd className="text-sm font-medium text-gray-900">${tax.toFixed(2)}</dd>
                  </div>
                  <div className="border-t border-gray-200 pt-4 flex items-center justify-between">
                    <dt className="text-base font-medium text-gray-900">Order total</dt>
                    <dd className="text-base font-medium text-gray-900">${total.toFixed(2)}</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;