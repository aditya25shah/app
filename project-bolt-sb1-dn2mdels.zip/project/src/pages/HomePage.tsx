import React from 'react';
import Hero from '../components/Hero';
import FeaturedProducts from '../components/FeaturedProducts';
import CategoryGrid from '../components/CategoryGrid';
import PromoSection from '../components/PromoSection';
import Newsletter from '../components/Newsletter';
import { products } from '../data/products';
import { categories } from '../data/categories';

const HomePage: React.FC = () => {
  // Filter featured products
  const featuredProducts = products.filter(product => product.featured);
  
  // Filter new arrivals
  const newArrivals = products.filter(product => product.new);
  
  // Filter products with discounts
  const discountedProducts = products.filter(product => product.discountedPrice);

  return (
    <div>
      <Hero />
      
      <PromoSection />
      
      <FeaturedProducts
        products={featuredProducts}
        title="Featured Products"
        subtitle="Handpicked by our experts"
        viewAllLink="/shop"
      />
      
      <CategoryGrid
        categories={categories}
        title="Shop by Category"
        subtitle="Find exactly what you're looking for"
        viewAllLink="/categories"
      />
      
      <FeaturedProducts
        products={newArrivals}
        title="New Arrivals"
        subtitle="The latest additions to our collection"
        viewAllLink="/new-arrivals"
      />
      
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-indigo-700 rounded-lg shadow-xl overflow-hidden">
            <div className="pt-10 pb-12 px-6 sm:pt-16 sm:px-16 lg:py-16 lg:pr-0 xl:py-20 xl:px-20">
              <div className="lg:self-center lg:max-w-3xl">
                <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
                  <span className="block">Summer Sale</span>
                  <span className="block">Up to 50% Off</span>
                </h2>
                <p className="mt-4 text-lg leading-6 text-indigo-200">
                  Limited time offer on selected items. Don't miss out on these amazing deals!
                </p>
                <a
                  href="/deals"
                  className="mt-8 bg-white border border-transparent rounded-md shadow px-6 py-3 inline-flex items-center text-base font-medium text-indigo-600 hover:bg-indigo-50"
                >
                  Shop the Sale
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <FeaturedProducts
        products={discountedProducts}
        title="Special Offers"
        subtitle="Limited-time deals you don't want to miss"
        viewAllLink="/deals"
      />
      
      <Newsletter />
    </div>
  );
};

export default HomePage;