import { Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Electronics',
    imageUrl: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    subcategories: [
      { id: '1-1', name: 'Smartphones' },
      { id: '1-2', name: 'Laptops' },
      { id: '1-3', name: 'Audio' },
      { id: '1-4', name: 'TVs' },
      { id: '1-5', name: 'Cameras' },
      { id: '1-6', name: 'Smart Home' }
    ]
  },
  {
    id: '2',
    name: 'Fashion',
    imageUrl: 'https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    subcategories: [
      { id: '2-1', name: 'Clothing' },
      { id: '2-2', name: 'Shoes' },
      { id: '2-3', name: 'Bags' },
      { id: '2-4', name: 'Accessories' },
      { id: '2-5', name: 'Jewelry' }
    ]
  },
  {
    id: '3',
    name: 'Home Decor',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    subcategories: [
      { id: '3-1', name: 'Furniture' },
      { id: '3-2', name: 'Lighting' },
      { id: '3-3', name: 'Textiles' },
      { id: '3-4', name: 'Wall Decor' },
      { id: '3-5', name: 'Kitchen' }
    ]
  },
  {
    id: '4',
    name: 'Beauty',
    imageUrl: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    subcategories: [
      { id: '4-1', name: 'Skincare' },
      { id: '4-2', name: 'Makeup' },
      { id: '4-3', name: 'Haircare' },
      { id: '4-4', name: 'Fragrance' },
      { id: '4-5', name: 'Bath & Body' }
    ]
  }
];